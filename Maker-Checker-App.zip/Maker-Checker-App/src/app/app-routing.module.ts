import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { MakerComponent } from './maker/maker.component';
import { CheckerFormComponent } from './checker-form/checker-form.component';
import {EditMakerComponent} from './edit-maker/edit-maker.component'
import { CheckerApprovalComponent } from './checker-approval/checker-approval.component';
import { ViewMakerInfoComponent } from './view-maker-info/view-maker-info.component';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  {path:'maker',component  : MakerComponent },
  {path:'checker-form',component  : CheckerFormComponent },
  {path:'edit-maker/:id',component  : EditMakerComponent },
  {path:'view-maker-info/:id',component  : ViewMakerInfoComponent },
  { path: '', redirectTo: '/maker', pathMatch: 'full' },
  {path:'checker-approval/:id',component  : CheckerApprovalComponent },
  {path:'login',component  : LoginComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
