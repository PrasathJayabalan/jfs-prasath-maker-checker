import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormBuilder, Validators } from '@angular/forms';
import { UserChecker } from '../model/checker.model';

@Injectable()
export class CheckerUserService {

  constructor( private http: HttpClient){
  }

  private Userurl = '/api';

  public getUsers() {
    return this.http.get<UserChecker[]>('http://localhost:8080/users');
  }
public createUser(user :UserChecker ){
console.log('rrrrrrrrrr'+ user.firstName);
  return this.http.post<UserChecker[]>( 'http://localhost:8080/users', user);
}
getUserById(id: number) {
  return this.http.get<UserChecker[]>('http://localhost:8080/users/find' + '/' + id);
}

public updateChecker(user  :UserChecker)
{
  return this.http.post<UserChecker[]>('http://localhost:8080/users/find' + '/' + user.id, user);
}


public approveUserReq(workFlowObj)
{
return this.http.post('http://localhost:8080/users', workFlowObj)
}


prepareForm(_fb: FormBuilder) {
  return _fb.group({
    id: [],
    firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
});
}
}
