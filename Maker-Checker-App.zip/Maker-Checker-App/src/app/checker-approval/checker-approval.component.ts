import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import { UserChecker } from '../model/checker.model';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
import { CheckerUserService } from '../services/checker.servies';

@Component({
  selector: 'app-checker-approval',
  templateUrl: './checker-approval.component.html',
  styleUrls: ['./checker-approval.component.css']
})
export class CheckerApprovalComponent implements OnInit {

  user: UserChecker;
  approvalForm: FormGroup;
  checkerApprovalId: any;
  isReadOnly: false;

  constructor(private router: Router, private _routeParams: ActivatedRoute, private formBuilder: FormBuilder, private checkeruserService: CheckerUserService) { }

  ngOnInit() {

    this.checkerApprovalId = this._routeParams.snapshot.params['id']
    this.approvalForm = this.formBuilder.group({
      id: [],
      email: ['', Validators.required],
      firstName: ['', Validators.required],
    lastName: ['', Validators.required],
    status:[]
  });

  this.apprejectUser();
    // this.checkeruserService.getUserById(+userId)
    //   .subscribe( data => {
    //     this.editForm.setValue(data);
    //   });
  }
  apprejectUser(){

    let approveform  = this.checkeruserService.prepareForm(this.formBuilder)
    this.checkeruserService.getUserById(this.checkerApprovalId)
    .subscribe((response: any) => {
      const editvalues: any = response;
      console.log(response);
      console.log(response.firstName);
      this.approvalForm.controls.id.setValue(response.id)
      this.approvalForm.controls.firstName.setValue(response.firstName)
      this.approvalForm.controls.lastName.setValue(response.lastName)
      this.approvalForm.controls.email.setValue(response.email)
  }
    )
}

approve()
{
  this.approvalForm.controls.status.setValue('A');
  this.checkeruserService.createUser(this.approvalForm.value)
  .subscribe( data =>{
    this.router.navigateByUrl('maker');
});

}
reject(){
  this.approvalForm.controls.status.setValue('R');
  this.checkeruserService.createUser(this.approvalForm.value)
  .subscribe( data =>{
    this.router.navigateByUrl('maker');
});
}

}
