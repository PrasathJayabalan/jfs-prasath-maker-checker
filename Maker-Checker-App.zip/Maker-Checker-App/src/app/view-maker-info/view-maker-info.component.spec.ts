import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewMakerInfoComponent } from './view-maker-info.component';

describe('ViewMakerInfoComponent', () => {
  let component: ViewMakerInfoComponent;
  let fixture: ComponentFixture<ViewMakerInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewMakerInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewMakerInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
