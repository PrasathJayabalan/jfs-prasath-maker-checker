import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import { UserChecker } from '../model/checker.model';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
import { CheckerUserService } from '../services/checker.servies';

@Component({
  selector: 'app-view-maker-info',
  templateUrl: './view-maker-info.component.html',
  styleUrls: ['./view-maker-info.component.css']
})
export class ViewMakerInfoComponent implements OnInit {
  user: UserChecker;
  viewForm: FormGroup;
  viewId: any;
  isReadOnly = false;
  constructor(private router: Router, private _routeParams: ActivatedRoute, private formBuilder: FormBuilder, private checkeruserService: CheckerUserService) { }

  ngOnInit() {
    this.viewId = this._routeParams.snapshot.params['id']
    this.viewForm = this.formBuilder.group({
      id: [],
      email: ['', Validators.required],
      firstName: ['', Validators.required],
    lastName: ['', Validators.required],
    status:[]
  });
  this.viewchecker();

  }
  viewchecker(): void{
    let viewcheckerinfo = this.checkeruserService.prepareForm(this.formBuilder)
    this.checkeruserService.getUserById(this.viewId)
    .subscribe((response: any) => {
      const viewvalues: any = response;
      console.log(response);
      console.log(response.firstName);
      this.viewForm.controls.id.setValue(response.id)
      this.viewForm.controls.firstName.setValue(response.firstName)
      this.viewForm.controls.lastName.setValue(response.lastName)
      this.viewForm.controls.email.setValue(response.email)
    }
    )
  }
}
