import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { CustomMaterialModule } from './core/material.module';
import { FormBuilder, FormGroup , FormControl , ReactiveFormsModule , FormsModule } from '@angular/forms';

import { LoginComponent } from './login/login.component';
import { MakerComponent } from './maker/maker.component';
import { CheckerFormComponent } from './checker-form/checker-form.component';
import { UserChecker } from './model/checker.model';
import { CheckerUserService } from './services/checker.servies';
import {HttpClientModule} from "@angular/common/http";
import { MakerlistComponent } from './makerlist/makerlist.component';
import { EditMakerComponent } from './edit-maker/edit-maker.component';
import { CheckerApprovalComponent } from './checker-approval/checker-approval.component';
import { UserListPipe } from './userList.pipe';
import { ViewMakerInfoComponent } from './view-maker-info/view-maker-info.component';




@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    MakerComponent,
    CheckerFormComponent,
    MakerlistComponent,
    EditMakerComponent,
    CheckerApprovalComponent,
    UserListPipe,
    ViewMakerInfoComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    AppRoutingModule,
    CustomMaterialModule,
    HttpClientModule,
    BrowserAnimationsModule],
  providers: [CheckerUserService],
  bootstrap: [AppComponent],

})
export class AppModule { }
