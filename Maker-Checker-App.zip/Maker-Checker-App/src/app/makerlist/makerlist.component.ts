import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-makerlist',
  templateUrl: './makerlist.component.html',
  styleUrls: ['./makerlist.component.css']
})
export class MakerlistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
