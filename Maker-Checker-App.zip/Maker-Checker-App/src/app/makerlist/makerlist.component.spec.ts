import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MakerlistComponent } from './makerlist.component';

describe('MakerlistComponent', () => {
  let component: MakerlistComponent;
  let fixture: ComponentFixture<MakerlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MakerlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MakerlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
