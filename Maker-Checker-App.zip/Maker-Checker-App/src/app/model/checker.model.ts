export class UserChecker {

  id: string;
  firstName: string;
  lastName: string;
  email: string;
  status: string;
}
