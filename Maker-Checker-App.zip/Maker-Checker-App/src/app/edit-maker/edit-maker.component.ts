import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import { UserChecker } from '../model/checker.model';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
import { CheckerUserService } from '../services/checker.servies';

@Component({
  selector: 'app-edit-maker',
  templateUrl: './edit-maker.component.html',
  styleUrls: ['./edit-maker.component.css']
})
export class EditMakerComponent implements OnInit {


  user: UserChecker;
  editForm: FormGroup;
  makerId: any;
  isReadOnly = false;
  constructor(private router: Router, private _routeParams: ActivatedRoute, private formBuilder: FormBuilder, private checkeruserService: CheckerUserService) { }

  ngOnInit() {
      this.makerId = this._routeParams.snapshot.params['id']

    // let userId = localStorage.getItem("editUserId");
    // if(!userId){
    //   alert("Invalid action")
    //   this.router.navigate(['edit-maker']);
    // }

   this.editForm = this.formBuilder.group({
       id: [],
       email: ['', Validators.required],
       firstName: ['', Validators.required],
     lastName: ['', Validators.required],
     status:[]
   });
   this.editUser();
    // this.checkeruserService.getUserById(+userId)
    //   .subscribe( data => {
    //     this.editForm.setValue(data);
    //   });
  }
  editUser(): void{
    // localStorage.setItem('editUserId', user.id.toString());
    let editformlist = this.checkeruserService.prepareForm(this.formBuilder)
    this.checkeruserService.getUserById(this.makerId)
    .subscribe((response: any) => {
      const editvalues: any = response;
      console.log(response);
      console.log(response.firstName);
      this.editForm.controls.id.setValue(response.id)
      this.editForm.controls.firstName.setValue(response.firstName)
      this.editForm.controls.lastName.setValue(response.lastName)
      this.editForm.controls.email.setValue(response.email)
    }
    )

  }
  changeStatus(status)
      {
        this.editForm.controls.status.setValue(status);
        this.onSubmit()
      }
  onSubmit()
  {
    this.checkeruserService.createUser(this.editForm.value)
    .subscribe( data =>{
      this.router.navigateByUrl('maker');
    })
  }

}
