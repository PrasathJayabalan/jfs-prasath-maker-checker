import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditMakerComponent } from './edit-maker.component';

describe('EditMakerComponent', () => {
  let component: EditMakerComponent;
  let fixture: ComponentFixture<EditMakerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditMakerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditMakerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
