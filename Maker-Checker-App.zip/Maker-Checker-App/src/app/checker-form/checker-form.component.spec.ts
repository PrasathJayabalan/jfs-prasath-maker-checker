import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckerFormComponent } from './checker-form.component';

describe('CheckerFormComponent', () => {
  let component: CheckerFormComponent;
  let fixture: ComponentFixture<CheckerFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckerFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckerFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
