import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserChecker } from '../model/checker.model';
import { CheckerUserService } from '../services/checker.servies';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-checker-form',
  templateUrl: './checker-form.component.html',
  styleUrls: ['./checker-form.component.css']
})
export class CheckerFormComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
  loan : any;
  model: any = {};

  user: UserChecker = new UserChecker();
  constructor(private router: Router, private checkeruserService: CheckerUserService, private formBuilder: FormBuilder ) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      loanType: ['', [Validators.required]]
  });
  this.loan=[
    {"id" :1, "name": "Credit", "code":"Credit"},
    {"id" :2, "name": "Debit", "code":"Credit"},
    {"id" :3, "name": "corporate Credit", "code":"Co-Credit"},
  ]
    };

    get f() { return this.registerForm.controls; }


  // createUser(): void {
  //   console.log("First......");
  //   this.checkeruserService.createUser(this.user)
  //   .subscribe( data => {
  //    // console.log( this.checkeruserService.createUser);
  //     alert("user created successfully")
  //   })
  // }
  onSubmit() {
    this.submitted = true;
    this.checkeruserService.createUser(this.registerForm.value)
    .subscribe( data => {
     // console.log( this.checkeruserService.createUser);
      alert("user created successfully")
      this.router.navigateByUrl('maker');
    })
    // stop here if form is invalid
    // if (this.registerForm.invalid) {
    //     return;
    // }

    // alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value))
}

}
