import { PipeTransform , Pipe} from '@angular/core';
import { UserChecker } from './model/checker.model';

@Pipe({

  name: 'checkerList'
})
export class UserListPipe implements PipeTransform{

  transform(users: UserChecker[], searchTerm: string):UserChecker[]
  {
  if( !users || !searchTerm)
  {
    return users;

  }
  return users.filter( userschecker =>
    userschecker.firstName.toLowerCase().indexOf(searchTerm.toLowerCase()) !== -1);

  }
}
