import { Component, OnInit } from '@angular/core';
import { Router, Routes, RouterModule } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import {ReactiveFormsModule} from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router,  private formBuilder: FormBuilder) {}
  loginForm: FormGroup;


  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]]
  });
  }
  makerchecker()
  {
    if(this.loginForm.controls.username.value ==='prasath' && this.loginForm.controls.password.value ==='123456')
    {
      this.router.navigateByUrl('maker');
    }
    // if(this.loginForm.controls.username.value ==='checker' && this.loginForm.controls.password.value ==='Astra@123')
    // {

    //   this.router.navigateByUrl('checker-form');
    // }
    else {
      alert( "You have not requested a login form!");
  }
  }
  makerclick(){

    this.router.navigateByUrl('maker');
  }

  checker(){
    this.router.navigateByUrl('checker-form');
  }


  }

