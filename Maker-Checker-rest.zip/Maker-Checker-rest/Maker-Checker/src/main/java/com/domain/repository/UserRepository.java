package com.domain.repository;


import org.springframework.data.jpa.repository.JpaRepository;

//package com.asterzeneca.MakerChecker;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.Repository;

import java.util.List;
import com.domain.entity.User;

//@org.springframework.stereotype.Repository
public interface UserRepository extends JpaRepository<User, Integer> {

	
	
	User findById(int id);
	
	//User update (User user);
	//User findById(int id);
}
