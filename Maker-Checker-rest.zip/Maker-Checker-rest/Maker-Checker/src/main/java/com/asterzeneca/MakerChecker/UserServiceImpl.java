package com.asterzeneca.MakerChecker;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.domain.entity.User;
import com.domain.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	
	 @Autowired
	 private UserRepository repository;

	public User create(User user) {
		// TODO Auto-generated method stub
		repository.save(user);
		return null;
	}

	public List<User> findAll() {
		// TODO Auto-generated method stub
		
		return (List<User>) repository.findAll();
	}

	   @Override
	    public User findById(int id) {
	        return repository.findById(id);
	    }
	
//public User update(User user)
//{
//	repository.save(user);
//	return null;
//	
//}
	
	   


}

