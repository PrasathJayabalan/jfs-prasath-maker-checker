package com.asterzeneca.MakerChecker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.bind.annotation.*;

import com.domain.entity.User;

import java.util.List;

@CrossOrigin//(origins ="http://localhost:4200", maxAge = 3600)
@RestController

//@RequestMapping({"/api"})
@RequestMapping({"/users"})
public class UserController {

	@Autowired
    private UserService userService;
	
	@PostMapping 
	public com.domain.entity.User create (@RequestBody  com.domain.entity.User user)
	{
		System.out.println(user);
		return userService.create(user);
	}
	
	 @GetMapping
	    public List<User> findAll(){
	        return userService.findAll();
	    }
	 
	 @GetMapping(path="/find/{id}")
	 public User findOne(@PathVariable(value ="id") int id) {
		 return userService.findById(id);
	 }
//	@PostMapping
//	public com.domain.entity.User ApproveUserReq (@RequestBody com.domain.entity.User user)
//	{
//		return userService.update(user);
//	}
}
