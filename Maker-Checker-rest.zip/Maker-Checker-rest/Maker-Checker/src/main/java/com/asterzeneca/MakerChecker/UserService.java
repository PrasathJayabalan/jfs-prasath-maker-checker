package com.asterzeneca.MakerChecker;


import java.util.List;
import com.domain.entity.User;

public interface UserService {
	
	public User create(User user);
	
	List<User> findAll();
	
	// User update(User user);
	User findById(int id);
	
	
	
}
